﻿namespace Arkanoid
{
    partial class Arkanoid
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.lblBolas = new System.Windows.Forms.Label();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.mnuNuevaPartida = new System.Windows.Forms.ToolStripMenuItem();
            this.lblControles = new System.Windows.Forms.Label();
            this.menuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer
            // 
            this.timer.Enabled = true;
            this.timer.Interval = 1;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // lblBolas
            // 
            this.lblBolas.AutoSize = true;
            this.lblBolas.BackColor = System.Drawing.Color.Maroon;
            this.lblBolas.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.lblBolas.Location = new System.Drawing.Point(12, 40);
            this.lblBolas.Name = "lblBolas";
            this.lblBolas.Size = new System.Drawing.Size(44, 13);
            this.lblBolas.TabIndex = 4;
            this.lblBolas.Text = "Bolas=x";
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuNuevaPartida});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(533, 24);
            this.menuStrip.TabIndex = 5;
            this.menuStrip.Text = "menuStrip1";
            // 
            // mnuNuevaPartida
            // 
            this.mnuNuevaPartida.Name = "mnuNuevaPartida";
            this.mnuNuevaPartida.Size = new System.Drawing.Size(91, 20);
            this.mnuNuevaPartida.Text = "nueva partida";
            this.mnuNuevaPartida.Click += new System.EventHandler(this.mnuNuevaPartida_Click);
            // 
            // lblControles
            // 
            this.lblControles.AutoSize = true;
            this.lblControles.BackColor = System.Drawing.Color.Maroon;
            this.lblControles.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.lblControles.Location = new System.Drawing.Point(129, 343);
            this.lblControles.Name = "lblControles";
            this.lblControles.Size = new System.Drawing.Size(50, 13);
            this.lblControles.TabIndex = 6;
            this.lblControles.Text = "controles";
            this.lblControles.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Arkanoid
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(533, 554);
            this.Controls.Add(this.lblControles);
            this.Controls.Add(this.lblBolas);
            this.Controls.Add(this.menuStrip);
            this.MainMenuStrip = this.menuStrip;
            this.Name = "Arkanoid";
            this.Text = "Arkanoid";
            this.Load += new System.EventHandler(this.Arkanoid_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Arkanoid_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Arkanoid_KeyUp);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.Label lblBolas;
        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem mnuNuevaPartida;
        private System.Windows.Forms.Label lblControles;
    }
}

