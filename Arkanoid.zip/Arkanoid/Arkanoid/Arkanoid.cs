﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Arkanoid.clases;

namespace Arkanoid
{
    public partial class Arkanoid : Form
    {
        const int filasBloques = 5; 
        const int bolasIniciales = 3;
        public List<Bola> listBolas;
        public List<Bloque> listBloques;
        public Jugador jugador;
        int nBolas;

        public Arkanoid()
        {
            InitializeComponent();
        }

        /*
        Dejo comentados los mensajes de consola que he usado en mis pruebas
         
        Para visualizarlos, en el Solution Explorer, ir a Properties(de Arkanoid, no Arkanoid.cs)/Aplication
        y cambiar el Output type a Console Application
        
        */

        private void mnuNuevaPartida_Click(object sender, EventArgs e)
        {
            while (listBolas.Count > 0)
            {
                listBolas[0].bola.Dispose();
                listBolas.RemoveAt(0);
            }
            while (listBloques.Count > 0)
            {
                listBloques[0].bloque.Dispose();
                listBloques.RemoveAt(0);
            }
            nBolas = bolasIniciales;
            nuevoConjuntoBloques();

            lblControles.Text = "Pulsa espacio para lanzar bolas";
            lblBolas.Text = "Bolas = " + nBolas;
        }

        private void Arkanoid_Load(object sender, EventArgs e)
        {
            listBolas = new List<Bola>();
            listBloques = new List<Bloque>();
            lblBolas.BackColor = Color.Transparent;
            lblControles.BackColor = Color.Transparent;
            lblControles.Text ="Flechas/ botones 'A' 'D' -> desplazamiento lateral"+Environment.NewLine
                + "Espacio -> lanzar bola" + Environment.NewLine
                + "Escape -> pausa" + Environment.NewLine + Environment.NewLine
                + "Pulsa en nueva partida para jugar";
            nuevoPalo();

        }

        public void nuevoPalo()
        {
            jugador = new Jugador(this);
        }

        public void nuevaBola()
        {
            if (nBolas > 0)
            {
                listBolas.Add(new Bola(this, jugador.palo.Location.X + jugador.palo.Size.Width / 2, jugador.palo.Location.Y - 30));
                nBolas--;
                lblControles.Text = "";
                lblBolas.Text = "Bolas = "+nBolas;
            }
        }

        public void nuevoBloque()
        {
            listBloques.Add(new Bloque(this));
        }

        public void nuevoConjuntoBloques()
        {
            int x;
            Bloque b;
            for (int i = 0; i < filasBloques; i++)
            {
                x = 0;
                while (ClientSize.Width / 2 - x > 0)
                {
                    b = new Bloque(this);
                    if (x == 0)
                    {
                        b.posicionar(ClientSize.Width / 2 - b.bloque.Size.Width / 2, 40 + (b.bloque.Size.Height + 10) * (i + 1));
                        listBloques.Add(b);
                        //Console.WriteLine("c"+i+" x "+b.bloque.Location.X + " y " + b.bloque.Location.Y);
                    }
                    else
                    {
                        b.posicionar(ClientSize.Width / 2 - b.bloque.Size.Width / 2 + x, 40 + (b.bloque.Size.Height + 10) * (i + 1));
                        listBloques.Add(b); 
                        //Console.WriteLine("d" + i + " x " + b.bloque.Location.X + " y " + b.bloque.Location.Y);
                        b = new Bloque(this);
                        b.posicionar(ClientSize.Width / 2 - b.bloque.Size.Width / 2 - x, 40 + (b.bloque.Size.Height + 10) * (i + 1));
                        listBloques.Add(b);
                        //Console.WriteLine("i" + i + " x " + b.bloque.Location.X + " y " + b.bloque.Location.Y);
                    }
                    x += b.bloque.Size.Width + 10;
                    
                }

            }
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            for (int i = 0; i < listBolas.Count; i++)
            {
                Bola b =listBolas[i];
                b.movimiento();
                if (b.bolaFuera)
                {
                    listBolas.RemoveAt(i);
                    b.bola.Dispose();
                    i--;
                }
            }
            jugador.movimiento();
        }

        private void Arkanoid_KeyDown(object sender, KeyEventArgs e)
        {
            controlPulsaciones(e, true);
        }

        private void Arkanoid_KeyUp(object sender, KeyEventArgs e)
        {
            controlPulsaciones(e, false);
        }

        private void controlPulsaciones(KeyEventArgs e, bool pulsado)
        {
            switch (e.KeyCode)
            {
                case Keys.Left:
                case Keys.A:
                    jugador.botonIzquierdo = pulsado;
                    break;

                case Keys.Right:
                case Keys.D:
                    jugador.botonDerecho = pulsado;
                    break;

                case Keys.Space: 
                    if (pulsado)
                        nuevaBola();
                    break;

                case Keys.Escape:
                    if(pulsado)
                        pausa();
                    break;
            }
        }

        private void pausa()
        {
            timer.Enabled = !timer.Enabled;
        }
    }
}
