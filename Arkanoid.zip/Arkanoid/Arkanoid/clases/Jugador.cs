﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Arkanoid.Properties;

namespace Arkanoid.clases
{
    public class Jugador
    {
        Arkanoid frmArkanoid;
        const int velXMax = 10;
        private int _velX;
        private PictureBox _palo;
        private bool _botonIzquierdo, _botonDerecho;

        public int velX
        {
            get { return _velX; }
            set { _velX = value; }
        }

        public PictureBox palo
        {
            get { return _palo; }
            set { _palo = value; }
        }
        public bool botonDerecho
        {
            get { return _botonDerecho; }
            set { _botonDerecho = value; }
        }

        public bool botonIzquierdo
        {
            get { return _botonIzquierdo; }
            set { _botonIzquierdo = value; }
        }


        public Jugador(Arkanoid frmArkanoid)
        {
            this.frmArkanoid = frmArkanoid;
            this.palo = new PictureBox();
            this.palo.Size = new System.Drawing.Size(104, 24);
            this.palo.Image = Resources.paddleRed;
            this.palo.BackColor = Color.Transparent;
            this.palo.Visible = true;
            this.frmArkanoid.Controls.Add(this.palo);
            posicionar();

        }

        public void posicionar()
        {
            palo.Location = new Point(frmArkanoid.ClientSize.Width / 2-palo.Width/2, frmArkanoid.ClientSize.Height -palo.Height*3);
        }


        public void movimiento()
        {
            if (botonIzquierdo && !botonDerecho && palo.Bounds.Left>0)
            {
                if (velX > -velXMax)
                {
                    //Console.WriteLine("i" + velX);
                    velX -= 1;
                }
            }
            else if (!botonIzquierdo && botonDerecho && palo.Bounds.Right < frmArkanoid.ClientSize.Width)
            {
                if (velX < velXMax)
                {
                    //Console.WriteLine("d" + velX);
                    velX += 1;

                }
            }
            else if (palo.Bounds.Left > 0 && palo.Bounds.Right < frmArkanoid.ClientSize.Width)
            {
                //frenado con deceleracion
                //Console.WriteLine("s");
                velX = (velX > 0) ? velX - 1 : (velX < 0) ? velX + 1 : 0;
            }
            else
            {
                //Console.WriteLine("x");
                velX = 0;
            }
            int x = palo.Location.X;
            int y = palo.Location.Y;
            palo.Location = new Point(x + velX,y);
        }
    }
}
