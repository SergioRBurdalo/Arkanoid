﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Arkanoid.Properties;

namespace Arkanoid.clases
{
    public class Bola
    {
        Arkanoid frmArkanoid;
        private int velX, velY;
        private bool _bolaFuera;
        private PictureBox _bola;

        public bool bolaFuera
        {
            get { return _bolaFuera; }
            set { _bolaFuera = value; }
        }

        public PictureBox bola
        {
            get { return _bola; }
            set { _bola = value; }
        }

        public Bola(Arkanoid frmArkanoid)
        {
            this.frmArkanoid = frmArkanoid;
            this.bola = new PictureBox();
            this.bola.Size = new System.Drawing.Size(22, 22);
            this.bola.Image = Resources.ballGrey;
            this.bola.BackColor = Color.Transparent;
            this.bola.Visible = true;
            this.frmArkanoid.Controls.Add(this.bola);
            bolaFuera = false;
            posicionar();
        }
        public Bola(Arkanoid frmArkanoid, int x, int y)
        {
            this.frmArkanoid = frmArkanoid;
            this.bola = new PictureBox();
            this.bola.Size = new System.Drawing.Size(22, 22);
            this.bola.Image = Resources.ballGrey;
            this.bola.BackColor = Color.Transparent;
            this.bola.Visible = true;
            this.frmArkanoid.Controls.Add(this.bola);
            bolaFuera = false;
            posicionar(x, y);
        }

        public void posicionar()
        {
            Random r = new Random();
            int x = r.Next(0, frmArkanoid.ClientSize.Width - bola.Width);
            int y = r.Next(0, frmArkanoid.ClientSize.Height - bola.Height);
            bola.Location = new Point(x,y);
            //velX = r.Next(1, 4);
            //velY = r.Next(1, 4);
            velX = 2;
            velY = 3;
            //direccion aleatoria
            if (r.Next(2) == 0)
                velX *= -1;
            if (r.Next(2) == 0)
                velY *= -1;
        }
        public void posicionar(int x, int y)
        {
            bola.Location = new Point(x, y);
            //velX = r.Next(1, 4);
            //velY = r.Next(1, 4);
            velX = 0;
            velY = 3;
        }


        public void movimiento()
        {
            int x = bola.Location.X;
            int y = bola.Location.Y;
            bola.Location = new Point(x + velX,y + velY);
            x = bola.Location.X;
            y = bola.Location.Y;
            //if ((bola.Bounds.Bottom > frmArkanoid.ClientSize.Height && velY > 0) || (bola.Bounds.Top < 0 && velY < 0)) //de querer que no se salga por abajo, usar este if
            if (bola.Bounds.Top < 0 && velY < 0)
            {
                velY *= -1;
            }
            if ((bola.Bounds.Right > frmArkanoid.ClientSize.Width && velX > 0) || (bola.Bounds.Left < 0 && velX < 0))
            {
                velX *= -1;
            }
            foreach (Bola b in frmArkanoid.listBolas)
            {
                if (this!=b &&bola.Bounds.IntersectsWith(b.bola.Bounds))
                {
                    velX *= -1;
                    velY *= -1;
                    bola.Location = new Point(x + velX, y + velY);
                }
            }
            Bloque bloque;
            for(int i=0;i<frmArkanoid.listBloques.Count;i++)
            {
                bloque = frmArkanoid.listBloques[i];
                if (bola.Bounds.IntersectsWith(bloque.bloque.Bounds))
                {
                    /*
                    Esta parte la uso para controlar que la bola solo rebote en x o y en funcion del lado en el
                    que de al bloque. A modo resumen, saco la distancia que hay entre los bordes X e Y de la bola y el
                    bloque. El mas corto es el que invierto. De ser igual en ambos casos (esquinas), invierto los dos
                     
                    */
                    int centroXBola = bola.Bounds.X + bola.Bounds.Width / 2;
                    int centroXBloque = bloque.bloque.Bounds.X + bloque.bloque.Bounds.Width / 2;
                    int centroYBola = bola.Bounds.Y + bola.Bounds.Height / 2;
                    int centroYBloque = bloque.bloque.Bounds.Y + bloque.bloque.Bounds.Height / 2;
                    int distanciaXMenor=(centroXBloque>centroXBola)
                        ?bloque.bloque.Bounds.Left - bola.Bounds.Right
                        :bola.Bounds.Left - bloque.bloque.Bounds.Right;
                    int distanciaYMenor=(centroYBloque>centroYBola)
                        ?bloque.bloque.Bounds.Top - bola.Bounds.Bottom
                        :bola.Bounds.Top - bloque.bloque.Bounds.Bottom;

                    if (Math.Abs(distanciaYMenor) < Math.Abs(distanciaXMenor))
                    {
                        //Console.WriteLine("colision vertical:" + distanciaYMenor+"<"+distanciaXMenor);
                        velY *= -1;
                    }
                    else if (Math.Abs(distanciaYMenor) > Math.Abs(distanciaXMenor))
                    {
                        //Console.WriteLine("colision horizontal:" + distanciaYMenor + ">" + distanciaXMenor);
                        velX *= -1;
                    }
                    else
                    {
                        //Console.WriteLine("colision diagonal:" + distanciaYMenor + "=" + distanciaXMenor);
                        velX *= -1;
                        velY *= -1;
                    }
                    bola.Location = new Point(x + velX, y + velY);


                    bloque.vida -= 1;
                    if (bloque.vida < 1)
                    {
                        frmArkanoid.listBloques.RemoveAt(i);
                        i--;
                        bloque.bloque.Dispose();
                    }
                    
                }
            }
            if (bola.Bounds.IntersectsWith(frmArkanoid.jugador.palo.Bounds))
            {
                /*
                Inclinacion de la bola en funcion de la distancia que este del centro de la barra.
                mejorable.
                 
                */
                int centroBola = bola.Bounds.Left + bola.Bounds.Size.Width / 2;
                int centroPalo = frmArkanoid.jugador.palo.Bounds.Left + frmArkanoid.jugador.palo.Size.Width / 2;
                int distanciaCentroPalo = centroBola - centroPalo;
                int distanciaMaxCentroPalo = frmArkanoid.jugador.palo.Bounds.Left + frmArkanoid.jugador.palo.Size.Width + bola.Bounds.Size.Width/2 - centroPalo;
                velX = distanciaCentroPalo / (int)((float)bola.Bounds.Size.Width / 1.75f);
                velY = -(Math.Abs(distanciaMaxCentroPalo / (int)((float)bola.Bounds.Size.Width / 1.75f)) - Math.Abs(velX)+1);
                //Console.WriteLine(velX+" "+velY);
                bola.Location = new Point(x + velX, y + velY);
            }
            if (bola.Bounds.Top > frmArkanoid.ClientSize.Height && velY > 0)
            {
                bolaFuera = true;
            }
        }

    }
}
