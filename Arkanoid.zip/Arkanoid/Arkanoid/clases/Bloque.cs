﻿using Arkanoid.Properties;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Arkanoid.clases
{
    public class Bloque
    {
        Arkanoid frmArkanoid;
        private PictureBox _bloque;
        public PictureBox bloque
        {
            get { return _bloque; }
            set { _bloque = value; }
        }

        private int _vida;
        public int vida
        {
            get { return _vida; }
            set
            {
                if (value == 1)
                {
                    this.bloque.Image = Resources.element_yellow_square;
                    bloque.Size = new System.Drawing.Size(32, 32);
                    bloque.Location = new Point(bloque.Location.X + bloque.Size.Width/2, bloque.Location.Y);
                }
                _vida = value;
            }
        }


        public Bloque(Arkanoid frmArkanoid)
        {
            this.frmArkanoid = frmArkanoid;
            this.bloque = new PictureBox();
            this.bloque.Size = new System.Drawing.Size(64, 32);
            this.bloque.Image = Resources.element_yellow_rectangle;
            this.bloque.BackColor = Color.Transparent;
            this.bloque.Visible = true;
            this.frmArkanoid.Controls.Add(this.bloque);
            vida = 2;
        }
        public Bloque(Arkanoid frmArkanoid,int x,int y)
        {
            this.frmArkanoid = frmArkanoid;
            this.bloque = new PictureBox();
            this.bloque.Size = new System.Drawing.Size(64, 32);
            this.bloque.Image = Resources.element_yellow_rectangle;
            this.bloque.BackColor = Color.Transparent;
            this.bloque.Visible = true;
            this.frmArkanoid.Controls.Add(this.bloque);
            posicionar(x,y);
        }
        public void posicionar()
        {
            Random r = new Random();
            int x = r.Next(0, frmArkanoid.ClientSize.Width - bloque.Width);
            int y = r.Next(0, frmArkanoid.ClientSize.Height - bloque.Height);
            bloque.Location = new Point(x, y);
        }
        public void posicionar(int x, int y)
        {
            bloque.Location = new Point(x, y);
        }
    }
}
